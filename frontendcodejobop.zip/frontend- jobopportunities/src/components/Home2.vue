<template>
<div>
    <table>
             <tr>
                 <td >
                     <button v-on:click="getJobDetails">Get Job Data</button>
                     <label> Jobs Posts List </label>
                     <select name="job" id="job" v-model="job" @change="changejob($event)">
                         <option value="" selected > - Select Job Posts -  </option>

                        <option v-for="jobdetails in resultForSpec" :value="jobdetails.jobId" :key="jobdetails.jobId" >
                                {{jobdetails.jobDescription}}
                            </option>
                     </select></td>

                       <td >
                           
                    <button v-on:click="getApplicantDetails">Get Applicant Data</button>
                     <label> Applicants List </label>
                     <select name="applicants" id="applicants" v-model="applicants" @change="changeapplicant($event)">
                         <option value="" selected > - Display Applicants -  </option>

                        <option v-for="applicantdetails in resultForSpec2" :value="applicantdetails.applicantId" :key="applicantdetails.applicantId" >
                                {{applicantdetails.applicantName}}
                            </option>
                     </select></td>

                       
             </tr>
               <button v-on:click="submitForm">Apply</button>
         </table>
  </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'Home2',
  data(){
        return{
           
                applicantName: '',
                Email: '',
                qualification: '',
                experiance: '',
                info:null,
                resultForSpec:[],
                resultForSpec1:[],
                resultForSpec2:[],
                resultsforjob:[],
                selectedjobname:null,
                job:'',
                applicants:''
            
        };
    },
    

    methods:{
        getJobDetails(){
          
        return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getAllJobs'
                     
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec=response.data;
                //alert("Applicant details called" + this.resultForSpec);
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
       
       },
      
        changejob(event){
                
            this.selectedjobid=event.target.value;
            this.selectedjobname= event.target.options[event.target.options.selectedIndex].text;
           
            
              
              let params1 = new URLSearchParams();               
                params1.append('JobId',this.selectedjobid);


             return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getApplicants',
                params :  params1 
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec1=response.data;
                //alert("Applicant details called " + response.data);
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        },
        
        changeapplicant(event){
              
            this.selectedapplicantid=event.target.value;
            this.selectedapplicantname= event.target.options[event.target.options.selectedIndex].text;
       
             
             

        },
        getapplicatantsID(){
          
              let params1 = new URLSearchParams();               
                params1.append('JobId',this.selectedjobid);


             return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getApplicants',
                params :  params1 
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec1=response.data;
               // alert("Applicant details called" + this.resultForSpec1);
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        },
      getApplicantDetails(){
          
        return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getAllApplicants'
                     
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec2=response.data;
                //alert("Applicant details called" + this.resultForSpec2);
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
       
       },
        submitForm(){
       

        let params1 = new URLSearchParams();
        
          params1.append('JobId',this.selectedjobid);
           params1.append('ApplicantId',this.selectedapplicantid);
          
          
          
            return new Promise((resolve,reject)=>{
              const req = {
                method: 'POST',
                url: 'http://localhost:8080/saveApplicants',
                params:params1            
              };
               
              axios(req).then((response) =>{
                alert("Applcant applied for Job Successfully");
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        }
    }
};
</script>
<style scoped>
.job-data {
  display: flex;
  align-items: center;
  margin-top: 20px;
  margin-left: 20px;
  border-bottom: 2px solid #ccc;
  padding: 20px;
}

.job-icon {
  flex-grow: 1;
}

.job-stats {
  flex-grow: 8;
  text-align: left;
  padding-left: 20px;
}

.job-stats .location {
  font-size: 30px;
}

.job-temp {
  flex-grow: 1;
  font-size: 35px;
}

img {
  width: 70px;
}

button {
  padding: 10px;
  background-color: #1aa832;
  color: white;
  border: 1px solid #ccc;
}
</style>
