<template>
  <b-navbar
    toggleable="md"
    type="dark"
    variant="info">
    <b-navbar-brand :to="{ name: 'Home' }">Job Posting </b-navbar-brand>
    <b-navbar-brand :to="{ name: 'Home1' }">Applicant  Posting </b-navbar-brand>
      
    <b-navbar-nav>
      <b-nav-item href="/Home2">Apply Jobs </b-nav-item>
      <b-nav-item href="/Home3">View Applicants for Applied Jobs</b-nav-item>
    </b-navbar-nav>
  </b-navbar>
</template>
<script>
export default {
  name: 'Navbar'
};
</script>
