<template>
 <div>
            
            <form v-on:submit.prevent="submitForm">
                <div class="form-group">
                    <label for="name">JobDescription</label>
                    <input type="text" class="form-control" id="name" placeholder="JobDescription" v-model="JobDescription">
                </div>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" id="email" placeholder="name@example.com"
                        v-model="Email">
                </div>
                  <div class="form-group">
                    <label for="MinQualification">MinQualification</label>
                    <input type="text" class="form-control" id="MinQualification" placeholder="MinQualification" v-model="MinQualification">
                </div>
                <div class="form-group">
                    <label for="MinExperiance">MinExperiance</label>
                    <input type="text" class="form-control" id="MinExperiance" placeholder="MinExperiance"
                        v-model="MinExperiance">
                </div>
             
                <div class="form-group">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </form>
    </div>
  
  
</template>
<script>
import axios from 'axios';
export default {
  name: 'Home',
  data(){
        return{
           
                JobDescription: '',
                Email: '',
                MinQualification: '',
                MinExperiance: '',
                info:null
            
        };
    },
    mounted(){
      
      axios.get('http://localhost:8080/getAllJobs').then(response => (this.info = response))
      
    },
    methods:{
    
        submitForm(){
          
        let params1 = new URLSearchParams();
        
          params1.append('JobDescription',this.JobDescription);
           params1.append('Email',this.Email);
            params1.append('MinQualification',this.MinQualification);
             params1.append('MinExperiance',this.MinExperiance);
          
          
            return new Promise((resolve,reject)=>{
              const req = {
                method: 'POST',
                url: 'http://localhost:8080/JobData',
                params:params1            
              };
               
              axios(req).then((response) =>{
                alert("Job Posted Successfully");
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        }
    }
}
    
</script>
<style scoped>
.homeText{
    font-size: 35px;
    color: red;
    text-align: center;
    position: relative;
    top:30px;
    text-shadow: 2px 2px 2px gray;
}
</style>
