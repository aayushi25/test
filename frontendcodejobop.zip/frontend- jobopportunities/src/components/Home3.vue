<template>
 <div>
         <table>

             <tr>
                 <td >
                     <label> Jobs Posts List </label>
                     <select name="job" id="job" v-model="job" @change="changejob($event)">
                         <option value="" selected > - Select Job Posts -  </option>

                        <option v-for="jobdetails in resultForSpec" :value="jobdetails.jobId" :key="jobdetails.jobId" >
                                {{jobdetails.jobDescription}}
                            </option>
                     </select></td>

                       <td >
                     <label> Applicants List </label>
                     <select name="applicants" id="applicants" v-model="applicants">
                         <option value="" selected > - Display Applicants -  </option>

                        <option v-for="applicantdetails in resultForSpec1" :value="applicantdetails.id" :key="applicantdetails.id" >
                                {{applicantdetails.applicantName}}
                            </option>
                     </select></td>

                       
             </tr>
         </table>
           
    </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'Home3',
  data(){
        return{
           
                applicantName: '',
                Email: '',
                qualification: '',
                experiance: '',
                info:null,
                resultForSpec:[],
                resultForSpec1:[],
                resultsforjob:[],
                selectedjobname:null,
                job:'',
                applicants:''
            
        };
    },
    mounted(){
          
        return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getAllJobs'
                     
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec=response.data;
               // alert("Applicant details called" + this.resultForSpec);
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
       
       },

    methods:{
        
      
        changejob(event){
            
            this.selectedjobid=event.target.value;
            this.selectedjobname= event.target.options[event.target.options.selectedIndex].text;
        
              let params1 = new URLSearchParams();               
                params1.append('JobId',this.selectedjobid);


             return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getApplicants',
                params :  params1 
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec1=response.data;
               
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        },
        getapplicatantsID(){
           
              let params1 = new URLSearchParams();               
                params1.append('JobId',this.selectedjobid);


             return new Promise((resolve,reject)=>{
              const req = {
                method: 'GET',
                url: 'http://localhost:8080/getApplicants',
                params :  params1 
              };
               
              axios(req).then((response) =>{
                  this.resultForSpec1=response.data;
               
             
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        },
        submitForm(){
         
        let params1 = new URLSearchParams();
        
          params1.append('applicantName',this.applicantName);
           params1.append('email',this.Email);
            params1.append('qualification',this.qualification);
             params1.append('experiance',this.experiance);
          
        
            return new Promise((resolve,reject)=>{
              const req = {
                method: 'POST',
                url: 'http://localhost:8080/ApplicantData',
                params:params1            
              };
               
              axios(req).then((response) =>{
                alert("Applicant details Saved Successfully");
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        }
    }
}
</script>
<style scoped>
.homeText{
    font-size: 35px;
    color: red;
    text-align: center;
    position: relative;
    top:30px;
    text-shadow: 2px 2px 2px gray;
}
</style>
