import Vue from 'vue';
import Router from 'vue-router';
import Home from '@/components/Home';
import Home1 from '@/components/Home1';
import Home2 from '@/components/Home2';
import Home3 from '@/components/Home3';
import NotFound from '@/components/error-pages/NotFound';

Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/Home1',
      name: 'Home1',
      component: Home1
    },
    {
      path: '/Home2',
      name: 'Home2',
      component: Home2
    },
    {
      path: '/Home3',
      name: 'Home3',
      component: Home3
    },
    {
      path: '*',
      name: 'NotFound',
      component: NotFound
    }
  ]
});
