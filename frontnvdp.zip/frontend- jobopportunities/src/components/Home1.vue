<template>
 <div>
            
            <form v-on:submit.prevent="submitForm">
                <div class="form-group">
                    <label for="name">Applicant Name</label>
                    <input type="text" class="form-control" id="name" placeholder="Your name" v-model="applicantName">
                </div>
                <div class="form-group">
                    <label for="email">Email ID</label>
                    <input type="email" class="form-control" id="email" placeholder="name@example.com"
                        v-model="Email">
                </div>
                  <div class="form-group">
                    <label for="qualification">Qualification</label>
                    <input type="text" class="form-control" id="qualification" placeholder="Your name" v-model="qualification">
                </div>
                <div class="form-group">
                    <label for="experiance">Experience</label>
                    <input type="text" class="form-control" id="experiance" placeholder="name@example.com"
                        v-model="experiance">
                </div>
             
                <div class="form-group">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </form>
    </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'Home1',
  data(){
        return{
           
                applicantName: '',
                Email: '',
                qualification: '',
                experiance: '',
                info:null
            
        };
    },

    methods:{
    
        submitForm(){
          alert("sdfsdfsdf");
        let params1 = new URLSearchParams();
         alert(this.applicantName);
          alert(params1);
          params1.append('applicantName',this.applicantName);
           params1.append('email',this.Email);
            params1.append('qualification',this.qualification);
             params1.append('experiance',this.experiance);
          
          alert(params1);
            return new Promise((resolve,reject)=>{
              const req = {
                method: 'POST',
                url: 'http://localhost:8080/ApplicantData',
                params:params1            
              };
               
              axios(req).then((response) =>{
                alert("Applicant details Saved Successfully");
                resolve();
              })
               .catch((error) => {
                 reject(error);
                     // error.response.status Check status code
                 })

            })
        }
    }
}
</script>
<style scoped>
.homeText{
    font-size: 35px;
    color: red;
    text-align: center;
    position: relative;
    top:30px;
    text-shadow: 2px 2px 2px gray;
}
</style>
