<template>
<div>
    <h1>My Job App</h1>
    <button v-on:click="getJobDetails">Get Job Data</button>
    <!--div v-for="jobData in jobDataList" :key="jobData.jobId" class="job-data"-->
      <div v-for="jobData in jobDataList" :key="jobData.jobId" :value="jobData.jobId" class="job-data">
      <div class="job-stats">
        <div>
          <span>{{jobData.JobDescription}}</span>
        </div>
        <div>
          <span class="location">{{jobData.MinQualification}}</span>
        </div>
         <div>
          <span class="location">{{jobData.MinExperiance}}</span>
        </div>
      </div>
      <div class="job-temp">
        <span>{{jobData.Email}}</span>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios';
export default {
  name: 'Home2',
  data(){
        return {
      jobDataList: []
    };
  },
  methods: {
    getJobDetails() {
      axios
        .get("http://localhost:8080/getAllJobs")
        .then(response => (this.jobDataList = response.data));
    alert(this.jobDataList);
    }
  }
};
</script>
<style scoped>
.job-data {
  display: flex;
  align-items: center;
  margin-top: 20px;
  margin-left: 20px;
  border-bottom: 2px solid #ccc;
  padding: 20px;
}

.job-icon {
  flex-grow: 1;
}

.job-stats {
  flex-grow: 8;
  text-align: left;
  padding-left: 20px;
}

.job-stats .location {
  font-size: 30px;
}

.job-temp {
  flex-grow: 1;
  font-size: 35px;
}

img {
  width: 70px;
}

button {
  padding: 10px;
  background-color: #1aa832;
  color: white;
  border: 1px solid #ccc;
}
</style>
